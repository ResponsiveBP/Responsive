Responsive layout with a maximum grid width of 1140px;

Sizes are as follows:

1280px viewport : 1140px grid

1024px viewport : 972px grid

768px viewport : 730px grid

600px viewport : 570px grid

480px viewport : 456px grid

320px viewport : 304px grid